package com.gametranslator.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import kotlin.math.max
import kotlin.math.min

data class TranslatedItem(val rect: Rect, val text: String)

/**
 * Menggambar hasil terjemahan tepat di atas posisi teks aslinya.
 * Koordinat sama dengan koordinat tangkapan layar (jendela overlay seukuran layar).
 */
class TranslationOverlayView(
    context: Context,
    items: List<TranslatedItem>
) : View(context) {

    private class Box(val rect: RectF, val layout: StaticLayout, val pad: Float)

    private val density = resources.displayMetrics.density

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(230, 20, 20, 30)
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(255, 255, 193, 7)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }

    private val boxes: List<Box> = items.map { buildBox(it) }

    private fun buildBox(item: TranslatedItem): Box {
        val pad = 6f * density
        val boxW = max(item.rect.width().toFloat(), 160f * density)
        val textW = (boxW - 2 * pad).toInt().coerceAtLeast(1)
        val maxTextSize = 24f * density
        val minTextSize = 11f * density
        val targetH = item.rect.height().toFloat() * 1.5f

        var size = min(item.rect.height().toFloat(), maxTextSize).coerceAtLeast(minTextSize)
        var layout: StaticLayout
        while (true) {
            // Paint baru untuk tiap layout supaya ukuran huruf tidak saling menimpa.
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = size
            }
            layout = StaticLayout.Builder
                .obtain(item.text, 0, item.text.length, paint, textW)
                .build()
            if (layout.height + 2 * pad <= targetH || size <= minTextSize) break
            size -= density
        }

        val left = item.rect.left.toFloat()
        val top = item.rect.top.toFloat()
        val rect = RectF(left, top, left + boxW, top + layout.height + 2 * pad)
        return Box(rect, layout, pad)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val radius = 6f * density
        for (box in boxes) {
            // Geser ke kiri bila kotak melewati tepi kanan layar.
            val dx = if (box.rect.right > width) width - box.rect.right else 0f
            canvas.save()
            canvas.translate(dx, 0f)
            canvas.drawRoundRect(box.rect, radius, radius, bgPaint)
            canvas.drawRoundRect(box.rect, radius, radius, borderPaint)
            canvas.translate(box.rect.left + box.pad, box.rect.top + box.pad)
            box.layout.draw(canvas)
            canvas.restore()
        }
    }
}
