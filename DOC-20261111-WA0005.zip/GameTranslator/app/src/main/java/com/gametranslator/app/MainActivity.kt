package com.gametranslator.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.mlkit.common.model.DownloadConditions

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var startButton: Button
    private var notificationAsked = false

    private val overlaySettingsLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) {
                onStartClicked()
            } else {
                setStatus(R.string.status_need_overlay)
            }
        }

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Layanan tetap berjalan walau notifikasi ditolak, jadi lanjutkan saja.
            onStartClicked()
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, OverlayService::class.java)
                    .putExtra(OverlayService.EXTRA_RESULT_CODE, result.resultCode)
                    .putExtra(OverlayService.EXTRA_DATA, data)
                ContextCompat.startForegroundService(this, intent)
                setStatus(R.string.status_running)
            } else {
                setStatus(R.string.status_projection_denied)
            }
            startButton.isEnabled = true
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        startButton = findViewById(R.id.startButton)

        startButton.setOnClickListener { onStartClicked() }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            setStatus(R.string.status_stopped)
        }
    }

    private fun onStartClicked() {
        // 1. Izin tampil di atas aplikasi lain (untuk tombol melayang)
        if (!Settings.canDrawOverlays(this)) {
            setStatus(R.string.status_need_overlay)
            overlaySettingsLauncher.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }

        // 2. Izin notifikasi (Android 13+), ditanyakan sekali
        if (Build.VERSION.SDK_INT >= 33 && !notificationAsked &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationAsked = true
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }

        // 3. Unduh model terjemahan, lalu minta izin perekaman layar
        startButton.isEnabled = false
        setStatus(R.string.status_downloading)
        TranslatorHolder.translator
            .downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                setStatus(R.string.status_model_ready)
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(manager.createScreenCaptureIntent())
            }
            .addOnFailureListener {
                setStatus(R.string.status_download_failed)
                startButton.isEnabled = true
            }
    }

    private fun setStatus(@StringRes res: Int) {
        statusText.setText(res)
    }
}
