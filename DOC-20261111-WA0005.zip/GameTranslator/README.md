# Penerjemah Game (Inggris → Indonesia)

Aplikasi Android dengan tombol "ID" melayang. Saat game berjalan, ketuk tombolnya:
layar ditangkap, teks Inggris dibaca (OCR), diterjemahkan ke Bahasa Indonesia,
dan hasilnya ditampilkan tepat di atas posisi teks aslinya. Ketuk hasilnya untuk menutup
(otomatis hilang setelah 12 detik).

- OCR: Google ML Kit Text Recognition (di perangkat)
- Terjemahan: Google ML Kit Translate (offline setelah model ±30 MB diunduh sekali)
- Android 8.0 (API 26) ke atas

## Cara mendapatkan APK

### Opsi A — build otomatis lewat GitHub (tanpa Android Studio)
1. Buat repositori baru di GitHub (boleh private).
2. Unggah **seluruh isi** folder proyek ini, termasuk folder tersembunyi `.github`
   (paling mudah dari komputer: ekstrak ZIP lalu seret semua isinya ke halaman repositori,
   atau pakai `git push`).
3. Buka tab **Actions** → workflow **Build APK** → tunggu selesai (±5 menit).
   Jika tidak jalan otomatis, tekan **Run workflow**.
4. Di halaman hasil build, unduh artefak **PenerjemahGame-APK** (ZIP berisi `app-debug.apk`).
5. Pindahkan APK ke HP, buka, dan izinkan "pasang dari sumber tidak dikenal".

### Opsi B — Android Studio
Buka folder proyek di Android Studio (Koala atau lebih baru), tunggu sinkronisasi Gradle,
lalu **Build → Build APK(s)**.

## Cara memakai
1. Buka aplikasi → **Mulai**.
2. Izinkan "Tampil di atas aplikasi lain", izin notifikasi, dan perekaman layar.
   (Saat pertama kali, perlu internet untuk mengunduh model terjemahan.)
3. Buka game. Ketuk tombol **ID** yang melayang untuk menerjemahkan layar. Tombol bisa digeser.
4. Berhenti lewat tombol **Berhenti** di aplikasi atau di notifikasi.

## Catatan
- Perekaman layar hanya dipakai di perangkat; tidak ada gambar yang dikirim ke server.
  Hanya unduhan model terjemahan yang memakai internet.
- Game yang memblokir tangkapan layar (flag FLAG_SECURE) akan menghasilkan layar hitam,
  sehingga tidak bisa diterjemahkan.
- Font game yang sangat dekoratif atau teks kecil bisa salah terbaca oleh OCR.
- Kode ini belum pernah dikompilasi di lingkungan pembuatnya; jika build gagal,
  kirim pesan error dari tab Actions agar bisa diperbaiki.
