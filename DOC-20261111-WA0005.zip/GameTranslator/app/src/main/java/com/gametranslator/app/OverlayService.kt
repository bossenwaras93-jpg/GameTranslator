package com.gametranslator.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.core.app.NotificationCompat
import androidx.core.content.IntentCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.abs

/**
 * Layanan latar depan: menampilkan tombol "ID" melayang. Saat diketuk, layar ditangkap,
 * teks Inggris dibaca (OCR), diterjemahkan ke Indonesia, lalu digambar di atas game.
 */
class OverlayService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "com.gametranslator.app.STOP"
        private const val CHANNEL_ID = "translator_channel"
        private const val NOTIF_ID = 1
        private const val RESULT_AUTO_DISMISS_MS = 12_000L
    }

    private lateinit var windowManager: WindowManager

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var lastW = 0
    private var lastH = 0
    private var lastDpi = 0

    private val captureThread = HandlerThread("capture").apply { start() }
    private val captureHandler by lazy { Handler(captureThread.looper) }

    @Volatile
    private var frameWaiter: CompletableDeferred<Bitmap?>? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private var bubble: View? = null
    private var resultView: TranslationOverlayView? = null
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Harus dipanggil sebelum getMediaProjection() di Android 14+.
        startForegroundCompat()

        if (projection == null) {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = manager.getMediaProjection(resultCode, data)
            if (mp == null) {
                stopSelf()
                return START_NOT_STICKY
            }
            projection = mp
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSelf()
                }
            }, Handler(Looper.getMainLooper()))
            setupVirtualDisplay(mp)
            showBubble()
        }
        return START_NOT_STICKY
    }

    // ---------------------------------------------------------------- notifikasi

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.app_name), NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .addAction(0, getString(R.string.notif_stop), stopIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    // ---------------------------------------------------------------- tangkap layar

    @Suppress("DEPRECATION")
    private fun screenSize(): Triple<Int, Int, Int> {
        val dm = DisplayMetrics()
        val display = (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        display.getRealMetrics(dm)
        return Triple(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    private fun newReader(w: Int, h: Int): ImageReader {
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader.setOnImageAvailableListener({ r ->
            val image = try {
                r.acquireLatestImage()
            } catch (e: Exception) {
                null
            }
            if (image != null) {
                val waiter = frameWaiter
                if (waiter != null && waiter.isActive) {
                    val bmp = try {
                        imageToBitmap(image)
                    } catch (e: Exception) {
                        null
                    }
                    frameWaiter = null
                    waiter.complete(bmp)
                }
                image.close()
            }
        }, captureHandler)
        return reader
    }

    private fun setupVirtualDisplay(mp: MediaProjection) {
        val (w, h, dpi) = screenSize()
        lastW = w; lastH = h; lastDpi = dpi
        val reader = newReader(w, h)
        imageReader = reader
        virtualDisplay = mp.createVirtualDisplay(
            "GameTranslator", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, captureHandler
        )
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(plane.buffer)
        if (padded.width == image.width) return padded
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    /**
     * Membuat ImageReader baru tiap tangkapan dan memasangnya ke virtual display. Ini memaksa
     * satu frame baru dikirim (juga saat layar sedang diam) dan menangani perubahan rotasi.
     */
    private suspend fun captureScreen(): Bitmap? {
        val vd = virtualDisplay ?: return null
        val (w, h, dpi) = screenSize()

        val deferred = CompletableDeferred<Bitmap?>()
        frameWaiter = deferred

        val old = imageReader
        val reader = newReader(w, h)
        imageReader = reader
        if (w != lastW || h != lastH || dpi != lastDpi) {
            vd.resize(w, h, dpi)
            lastW = w; lastH = h; lastDpi = dpi
        }
        vd.surface = reader.surface
        old?.close()

        val bitmap = withTimeoutOrNull(1500) { deferred.await() }
        frameWaiter = null
        return bitmap
    }

    // ---------------------------------------------------------------- OCR + terjemah

    private suspend fun recognizeAndTranslate(bmp: Bitmap): List<TranslatedItem> {
        val text = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
        val translator = TranslatorHolder.translator
        translator.downloadModelIfNeeded().await()

        val out = mutableListOf<TranslatedItem>()
        for (block in text.textBlocks) {
            val rect = block.boundingBox ?: continue
            val source = block.text.replace('\n', ' ').trim()
            if (source.length < 2 || source.none { it.isLetter() }) continue
            val translated = try {
                translator.translate(source).await()
            } catch (e: Exception) {
                continue
            }
            out.add(TranslatedItem(rect, translated))
        }
        return out
    }

    // ---------------------------------------------------------------- tombol melayang

    private fun showBubble() {
        val view = LayoutInflater.from(this).inflate(R.layout.bubble, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16
            y = 300
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        view.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f
            private var moved = false

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = e.rawX
                        touchY = e.rawY
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - touchX).toInt()
                        val dy = (e.rawY - touchY).toInt()
                        if (abs(dx) > slop || abs(dy) > slop) moved = true
                        if (moved) {
                            params.x = startX + dx
                            params.y = startY + dy
                            windowManager.updateViewLayout(v, params)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            v.performClick()
                            onBubbleTap()
                        }
                    }
                    else -> return false
                }
                return true
            }
        })

        windowManager.addView(view, params)
        bubble = view
    }

    private fun onBubbleTap() {
        if (resultView != null) {
            dismissResult()
            return
        }
        if (busy) return
        busy = true
        bubble?.visibility = View.INVISIBLE // agar tombol tidak ikut terbaca OCR

        scope.launch {
            try {
                delay(180) // beri waktu layar menggambar ulang tanpa tombol
                val bmp = withContext(Dispatchers.Default) { captureScreen() }
                bubble?.visibility = View.VISIBLE
                if (bmp == null) {
                    toast(R.string.toast_capture_failed)
                    return@launch
                }
                toast(R.string.toast_translating)
                val items = withContext(Dispatchers.Default) { recognizeAndTranslate(bmp) }
                val width = bmp.width
                val height = bmp.height
                bmp.recycle()
                if (items.isEmpty()) {
                    toast(R.string.toast_no_text)
                } else {
                    showResult(items, width, height)
                }
            } catch (e: Exception) {
                toast(R.string.toast_error)
            } finally {
                bubble?.visibility = View.VISIBLE
                busy = false
            }
        }
    }

    private fun showResult(items: List<TranslatedItem>, width: Int, height: Int) {
        val view = TranslationOverlayView(this, items)
        view.setOnClickListener { dismissResult() }

        val params = WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        windowManager.addView(view, params)
        resultView = view

        scope.launch {
            delay(RESULT_AUTO_DISMISS_MS)
            if (resultView === view) dismissResult()
        }
    }

    private fun dismissResult() {
        resultView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: IllegalArgumentException) {
                // sudah dilepas
            }
        }
        resultView = null
    }

    private fun toast(@StringRes res: Int) {
        Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------- bersih-bersih

    override fun onDestroy() {
        scope.cancel()
        dismissResult()
        bubble?.let {
            try {
                windowManager.removeView(it)
            } catch (e: IllegalArgumentException) {
                // sudah dilepas
            }
        }
        bubble = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.stop()
        projection = null
        recognizer.close()
        captureThread.quitSafely()
        super.onDestroy()
    }
}
